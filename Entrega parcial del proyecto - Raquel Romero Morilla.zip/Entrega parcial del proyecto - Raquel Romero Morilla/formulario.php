<?php
include("conexion.php");

$id = isset($_GET['id']) ? $_GET['id'] : '';
$nombre = "";
$imagen = "";
$stock = "";

if($id){
    $res = $conexion->query("SELECT * FROM articulos WHERE id=$id");
    $art = $res->fetch_assoc();
    $nombre = $art['nombre'];
    $imagen = $art['imagen'];
    $stock = $art['stock'];
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Artículo</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<h1><?php echo $id ? "Editar Artículo" : "Añadir Artículo"; ?></h1>

<form action="guardar.php" method="POST">
    <input type="hidden" name="id" value="<?php echo $id; ?>">
    
    <input type="text" name="nombre" placeholder="Nombre" value="<?php echo $nombre; ?>" required>
    <input type="text" name="imagen" placeholder="URL imagen" value="<?php echo $imagen; ?>" required>
    <input type="number" name="stock" placeholder="Stock" value="<?php echo $stock; ?>" required>

    <button type="submit">Guardar</button>
    <a href="index.php"><button type="button">Volver</button></a>
</form>

</body>
</html>

<?php
include("conexion.php");

$busqueda = isset($_GET['busqueda']) ? $_GET['busqueda'] : '';
$orden = isset($_GET['orden']) && $_GET['orden'] == 'DESC' ? 'DESC' : 'ASC';

$sql = "SELECT * FROM articulos WHERE 
LOWER(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(nombre,'á','a'),'é','e'),'í','i'),'ó','o'),'ú','u'))
LIKE LOWER('%$busqueda%')
ORDER BY nombre $orden";

$resultado = $conexion->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Inventario Pro</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<h1>GESTIÓN DE EQUIPOS</h1>

<form method="GET">
    <input type="text" name="busqueda" placeholder="¿Qué estás buscando?" value="<?php echo $busqueda; ?>">
    
    <select name="orden">
        <option value="ASC" <?php if($orden=='ASC') echo 'selected'; ?>>A-Z</option>
        <option value="DESC" <?php if($orden=='DESC') echo 'selected'; ?>>Z-A</option>
    </select>

    <button type="submit">FILTRAR</button>
    <a href="formulario.php" style="text-decoration:none;"><button type="button" style="background:#10b981;">NUEVO</button></a>
</form>

<div class="grid">
<?php while($art = $resultado->fetch_assoc()): ?>
    <div class="card">
        <img src="<?php echo $art['imagen']; ?>" alt="">
        <h3><?php echo $art['nombre']; ?></h3>
        <p>Disponibles: <strong><?php echo $art['stock']; ?></strong></p>
        <a href="formulario.php?id=<?php echo $art['id']; ?>">EDITAR</a>
        <a href="eliminar.php?id=<?php echo $art['id']; ?>" 
           onclick="return confirm('¿Borrar definitivamente?')">ELIMINAR</a>
    </div>
<?php endwhile; ?>
</div>

</body>
</html>
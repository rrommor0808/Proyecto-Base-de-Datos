<?php

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

try {
    $conexion = new mysqli("localhost", "root", "", "inventario_db");
    $conexion->set_charset("utf8");

} catch (Exception $e) {
    die("Error crítico de conexión: " . $e->getMessage());
}
?>

<?php
include("conexion.php");

$id = $_POST['id'];
$nombre = $_POST['nombre'];
$imagen = $_POST['imagen'];
$stock = $_POST['stock'];

if($id){
    $conexion->query("UPDATE articulos SET 
        nombre='$nombre',
        imagen='$imagen',
        stock=$stock
        WHERE id=$id");
} else {
    $conexion->query("INSERT INTO articulos (nombre, imagen, stock) 
        VALUES ('$nombre','$imagen',$stock)");
}

header("Location: index.php");
exit;
?>
